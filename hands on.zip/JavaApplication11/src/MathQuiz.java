import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.Timer;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

public class MathQuiz extends JFrame implements ActionListener{
    
    static final int MAX_QUESTIONS = 10;
    
    // Start and Stop button
    private JButton btStart, btStop;
    
    // radio buttons for question type
    JRadioButton rdBtAdd, rdBtSubtract, rdBtMultiply, rdBtDivide;
    
    // radio buttons for selecting a level
    JRadioButton rdBtLevel0To5, rdBtLevel3To9, rdBtLevel0To20, rdBtLevelAnyTwoDigits;
    
    // button for the quetion type and level
    ButtonGroup grType, grLevel;
    
    // text box for answer
    JTextField txAnswer;
    
    // random number generator
    Random rand = new Random();
    
    // the timer
    Timer timer = new Timer(1000, this);
    
    // count of correct answers
    int correctCount = 0;
    
    // number of seconds elapased 
    int secsElapsed = 0;
    
    // numbers of the current question
    int number1, number2;
    
    // range of numbers as per level
    int numberMax=0, numberMin=5;
    
    // answer of current question
    int answer;
    
    // count of questions being asked
    int countQuestions = 0;
    
    // text for question, correct count and time spent
    JLabel lblQuestion, lblCorrectCount, lblTimeSpent;
    
    public MathQuiz(){
        super("MathQuiz");
        Container cont = this.getContentPane();
        cont.setLayout(new BorderLayout());
        
        // create the top panel to show question type and level
        JPanel p1 = new JPanel();
        p1.setLayout(new GridLayout(1, 2, 5, 0));
        JPanel p1Child1 = new JPanel();
        p1Child1.setBorder(new CompoundBorder(new TitledBorder("Choose a type"), new EmptyBorder(5, 5, 5, 5)));
        p1Child1.setLayout(new BoxLayout(p1Child1, BoxLayout.Y_AXIS));
        grType = new ButtonGroup();        
        rdBtAdd = new JRadioButton("Add", true);
        grType.add(rdBtAdd);
        rdBtSubtract = new JRadioButton("Subtract");
        grType.add(rdBtSubtract);
        rdBtMultiply = new JRadioButton("Multiply");
        grType.add(rdBtMultiply);
        rdBtDivide = new JRadioButton("Divide");
        grType.add(rdBtDivide);
        p1Child1.add(rdBtAdd);
        p1Child1.add(rdBtSubtract);
        p1Child1.add(rdBtMultiply);
        p1Child1.add(rdBtDivide);
        p1.add(p1Child1);
        
        JPanel p1Child2 = new JPanel();
        p1Child2.setBorder(new CompoundBorder(new TitledBorder("Choose a level"), new EmptyBorder(5, 5, 5, 5)));
        p1Child2.setLayout(new BoxLayout(p1Child2, BoxLayout.Y_AXIS));
        grLevel = new ButtonGroup();
        rdBtLevel0To5 = new JRadioButton("Numbers from 0 to 5", true);
        rdBtLevel0To5.addActionListener(this);
        grLevel.add(rdBtLevel0To5);
        rdBtLevel3To9 = new JRadioButton("Numbers from 3 to 9", true);
        rdBtLevel3To9.addActionListener(this);
        grLevel.add(rdBtLevel3To9);
        rdBtLevel0To20 = new JRadioButton("Numbers from 0 to 20", true);
        rdBtLevel0To20.addActionListener(this);
        grLevel.add(rdBtLevel0To20);
        rdBtLevelAnyTwoDigits= new JRadioButton("Any two digits", true);
        rdBtLevelAnyTwoDigits.addActionListener(this);
        grLevel.add(rdBtLevelAnyTwoDigits);
        p1Child2.add(rdBtLevel0To5);
        p1Child2.add(rdBtLevel3To9);
        p1Child2.add(rdBtLevel0To20);
        p1Child2.add(rdBtLevelAnyTwoDigits);
        p1.add(p1Child2);
        
        // create the middle panel to question and answer input text box
        JPanel p2 = new JPanel(new GridLayout(1, 2));
        JPanel p2Child1 = new JPanel(new BorderLayout());
        //p2Child1.setBorder(new CompoundBorder(new TitledBorder("Correct Count"), new EmptyBorder(5, 5, 5, 5)));
        JLabel l1 = new JLabel("Question:");
        l1.setAlignmentX(0.0f);
        p2Child1.add(l1, BorderLayout.NORTH);
        lblQuestion = new JLabel("Question will be shown");
        lblQuestion.setHorizontalAlignment(JLabel.RIGHT);
        p2Child1.add(lblQuestion, BorderLayout.CENTER);
        p2.add(p2Child1);
        JPanel p = new JPanel();
        p.setBorder(new EmptyBorder(17, 5, 5, 10));
        p2Child1.add(p, BorderLayout.SOUTH);
        JPanel p2Child2 = new JPanel(new BorderLayout());
        //p2Child2.setBorder(new CompoundBorder(new TitledBorder("Time Spent"), new EmptyBorder(5, 5, 5, 5)));
        l1 = new JLabel("Answer:");
        l1.setAlignmentX(0.0f);
        p2Child2.add(l1, BorderLayout.NORTH);
        txAnswer = new JTextField(15);
        txAnswer.addActionListener(this);
        p2Child2.add(txAnswer, BorderLayout.CENTER);
        p2.add(p2Child2);
        
        JPanel p2Child3 = new JPanel(new FlowLayout(FlowLayout.TRAILING));
        // create the Start button
        btStart = new JButton("Start");
        btStart.addActionListener(this);
        p2Child3.add(btStart);
        
        // create the Stop button
        btStop = new JButton("Stop");
        btStop.addActionListener(this);
        p2Child3.add(btStop);
        p2Child2.add(p2Child3, BorderLayout.SOUTH);
        
        // create the bottom panel to show correct count and time spent
        JPanel p3 = new JPanel(new GridLayout(1, 2));
        JPanel p3Child1 = new JPanel(new BorderLayout());
        p3Child1.setBorder(new CompoundBorder(new TitledBorder("Correct Count"), new EmptyBorder(5, 5, 5, 5)));
        
        // create the lable for correct count
        lblCorrectCount = new JLabel("Correct count will be shown");
        p3Child1.add(lblCorrectCount, BorderLayout.CENTER);
        p3.add(p3Child1);
        
        // create the lable for time spent
        JPanel p3Child2 = new JPanel(new BorderLayout());
        p3Child2.setBorder(new CompoundBorder(new TitledBorder("Time Spent"), new EmptyBorder(5, 5, 5, 5)));
        lblTimeSpent = new JLabel("Time spent will be shown");
        p3Child2.add(lblTimeSpent, BorderLayout.CENTER);
        p3.add(p3Child2);
        
        
        // add all the panels to the frame
        cont.add(p1, BorderLayout.NORTH);
        cont.add(p2, BorderLayout.CENTER);
        cont.add(p3, BorderLayout.SOUTH);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        // handle all the change in radio buttons, button click events and
        // answer text box ENTER event
        
        // get the UI control that caused the event
        Object src = e.getSource();
        if(src == timer){
            // timer fired after 1 sec
            secsElapsed++;
            lblTimeSpent.setText(secsElapsed + " seconds");
        }
        else if(src == btStart){
            // Start 
            start();
        }else if(src == btStop){
            // Stop
            stop();
        }else if(src == txAnswer){
            // answer text box ENTER
            if(timer.isRunning()){
                String input = txAnswer.getText();
                try{
                    int userAns = Integer.parseInt(input);
                    if(userAns == answer){
                        correctCount++;
                        lblCorrectCount.setText("" + correctCount);
                    }
                }catch(NumberFormatException ex){                    
                }
                txAnswer.setText("");
                generateQuestionAnswer();
                countQuestions++;
                if(countQuestions == MAX_QUESTIONS){
                    String msg = "***** QUIZ OVER ******\n";
                    msg += "Score: "+correctCount+"/"+MAX_QUESTIONS;
                    JOptionPane.showMessageDialog(this, msg, "Score", JOptionPane.INFORMATION_MESSAGE);                    
                    stop();
                }
            }
        }
    }
   
    // Stop the quiz and reset UI
    private void stop() {
        correctCount = 0;
        countQuestions = 0;
        secsElapsed = 0;
        if(timer.isRunning())
            timer.stop();
        btStop.setEnabled(false);
        btStart.setEnabled(true);
        lblQuestion.setText("Question will be shown");
    }
    
    // Start the quiz again
    private void start() {
        correctCount = 0;
        lblCorrectCount.setText("0");
        lblTimeSpent.setText("0 secs");
        generateQuestionAnswer();
        timer.start();
        btStart.setEnabled(false);
        btStop.setEnabled(true);
    }
    
    // generate two numbers and the answer as per question type
    // and level
    private void generateQuestionAnswer() {
        String question = "";
        
        if (rdBtLevel0To5.isSelected()) {
            // generate two numbers between 0 to 5
            number1 = rand.nextInt(6);
            number2 = rand.nextInt(6);
            if(rdBtDivide.isSelected() && number2 == 0){
                while(number2 == 0){
                    number2 = rand.nextInt(6);
                }
            }
        } else if (rdBtLevel3To9.isSelected()) {
            // generate two numbers between 3 to 9
            number1 = 3 + rand.nextInt(4);
            number2 = 3 + rand.nextInt(4);
            if(rdBtDivide.isSelected() && number2 == 0){
                while(number2 == 0){
                    number2 = 3 + rand.nextInt(4);
                }
            }
        } else if (rdBtLevel0To20.isSelected()) {
            // generate two numbers between 0 to 20
            number1 = rand.nextInt(21);
            number2 = rand.nextInt(21);
            if(rdBtDivide.isSelected() && number2 == 0){
                while(number2 == 0){
                    number2 = rand.nextInt(21);
                }
            }
        }else{
            // generate two numbers with any two digits
            number1 = 10 + rand.nextInt(91);
            number2 = 10 + rand.nextInt(91);
            if(rdBtDivide.isSelected() && number2 == 0){
                while(number2 == 0){
                    number2 = 10 + rand.nextInt(91);
                }
            }
        }
        // compute the answer
        if (rdBtAdd.isSelected()) {
            question = String.format("%d + %d = ", number1, number2);
            answer = number1 + number2;
        } else if (rdBtSubtract.isSelected()) {
            question = String.format("%d - %d = ", number1, number2);
            answer = number1 - number2;
        } else if (rdBtMultiply.isSelected()) {
            question = String.format("%d * %d = ", number1, number2);
            answer = number1 * number2;
        } else {
            question = String.format("%d / %d = ", number1, number2);
            answer = number1 / number2;
        }
        // display the question
        lblQuestion.setText(question);
    }
    
    public static void main(String[] args){
        MathQuiz quiz = new MathQuiz();
        quiz.setDefaultCloseOperation(EXIT_ON_CLOSE);
        quiz.setSize(600, 280);
        quiz.setVisible(true);
        quiz.setResizable(false);
        quiz.setLocationRelativeTo(null);
    }
}
